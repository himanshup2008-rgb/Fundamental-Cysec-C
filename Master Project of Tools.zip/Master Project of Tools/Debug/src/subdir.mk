################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/Checker.c \
../src/Cipher.c \
../src/HexDump.c \
../src/MasterProjectTools.c \
../src/XOR.c 

C_DEPS += \
./src/Checker.d \
./src/Cipher.d \
./src/HexDump.d \
./src/MasterProjectTools.d \
./src/XOR.d 

OBJS += \
./src/Checker.o \
./src/Cipher.o \
./src/HexDump.o \
./src/MasterProjectTools.o \
./src/XOR.o 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross GCC Compiler'
	gcc -std=c11 -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-src

clean-src:
	-$(RM) ./src/Checker.d ./src/Checker.o ./src/Cipher.d ./src/Cipher.o ./src/HexDump.d ./src/HexDump.o ./src/MasterProjectTools.d ./src/MasterProjectTools.o ./src/XOR.d ./src/XOR.o

.PHONY: clean-src

