src/XOR.o: ../src/XOR.c ../src/XOR.h
../src/XOR.h:
