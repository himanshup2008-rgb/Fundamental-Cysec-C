src/Master Project of Tools.o: ../src/Master\ Project\ of\ Tools.c
