src/HexDump.o: ../src/HexDump.c ../src/HexDump.h
../src/HexDump.h:
