src/Password Checker.o: ../src/Password\ Checker.c \
 ../src/Password\ Checker.h
../src/Password\ Checker.h:
