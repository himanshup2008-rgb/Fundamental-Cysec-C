src/MasterProjectTools.o: ../src/MasterProjectTools.c ../src/Cipher.h \
 ../src/Checker.h ../src/HexDump.h ../src/XOR.h
../src/Cipher.h:
../src/Checker.h:
../src/HexDump.h:
../src/XOR.h:
