src/HexDump tool.o: ../src/HexDump\ tool.c ../src/HexDump.h
../src/HexDump.h:
