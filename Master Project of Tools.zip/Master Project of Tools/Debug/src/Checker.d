src/Checker.o: ../src/Checker.c ../src/Checker.h
../src/Checker.h:
