src/XOR Encryptor.o: ../src/XOR\ Encryptor.c ../src/XOR.h
../src/XOR.h:
