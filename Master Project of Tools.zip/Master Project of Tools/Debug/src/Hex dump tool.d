src/Hex dump tool.o: ../src/Hex\ dump\ tool.c ../src/Hex\ Dump.h
../src/Hex\ Dump.h:
