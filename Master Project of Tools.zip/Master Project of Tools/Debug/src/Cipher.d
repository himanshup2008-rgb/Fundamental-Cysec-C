src/Cipher.o: ../src/Cipher.c ../src/Cipher.h
../src/Cipher.h:
