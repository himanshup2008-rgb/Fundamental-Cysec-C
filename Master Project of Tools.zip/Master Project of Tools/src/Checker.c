/*
 ============================================================================
 Name        : Password.c
 Author      : Himanshu Prasad Pandey
 Copyright   : The most basic program here I wont need a copyright.
 Description : Hello World in C.
 ============================================================================
 */
#include "Checker.h"

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdbool.h>


int Checker_main () {
    char Password[256]; /*Char array of 256*/
    int strength = 0; /*Password strength*/
    setbuf(stdout, NULL); /*Nothing that matters code runs without it as well*/

    printf("Enter the Password: ");
    scanf("%s", Password); /*Gets your text*/
    int characters=strlen(Password); /*Counts your text characters*/

    bool hasupper=false; bool haslower=false; bool hasnumber=false; bool hassymbol=false; /*True or false basically for uppercase, lowercase, number and symbol/space*/

    for (int i=0; Password[i] !='\0'; i++) { /*Basic for loop*/
        char c=Password[i];

        if (isupper(c)) /*Basic if else, if c is upper case set hasupper variable to true. c here is Password[i] where i is the current character loop*/
            hasupper=true;
        else if (islower(c))
            haslower=true;
        else if (isdigit(c))
            hasnumber=true;
        else hassymbol=true;

    }
    printf("You typed in %s", Password); /*Tell you what your password is in ASCII smack on the screen*/

    if (hasupper==true) { /*If else to add strength for each variation and print what sort of characters exist in your password.*/
        strength++;
        printf("\nhas an uppercase");
    }
    if (haslower==true) {
        strength++;
        printf("\nhas an lowercase");
    }
    if (hasnumber==true) {
        strength++;
        printf("\nhas a number");
    }
    if (hassymbol==true){
        strength++;
        printf("\nhas a symbol or a space");
    }

    if (characters>=12){ /*if characters are 12*/
        strength=strength+2; /*add +2 to strength*/
        printf("\nhas 12+ characters");
}

    else if(characters>=8) { /*else if characters are 8*/
        strength=strength+1; /*add plus 1*/
            printf("\nhas 8+ characters");} /*print what number of characters it as either 8 or 12*/

printf("\nStrength level: %d",strength);
    if (strength<=2) { /*Counts strength and name calls your password by printing it out.*/
        printf("\nThe Password is weak");
    }
        else if (strength<=4) {
            printf("\nThe Password is morderate");
        }
            else {printf("\nThe Password is strong");}

    return 0;
    printf("\nPress ENTER to exit...");
        	    getchar();
        	    getchar();

            }


