/*
 ============================================================================
 Name        : Caesar.c
 Author      : Himanshu Prasad Pandey
 Copyright   : Anyone can do this in today's day learning from it is what's important!
 Description : Caesar Cipher in C. I took my time optimizing and debugging this. One of the programs I gave a bit of love.
 ============================================================================
 */

#include "Cipher.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void encrypt(char text[], int shift) { /*SO this is a function. For encryption  */
	shift %= 26; /*A modulo to keep the text shift in line with 0-25 even if it is shifted by 30000. Here each text is an integer of 0-25 since everyone knows there are 26 alphabets, hell even apes and elephants do.*/

    for (int i = 0; i < strlen(text); i++) { /*Looping through characters basically.*/
        char t =text[i]; /*t is the current character basically.*/
        if (t >= 'a' && t <= 'z'){ /*This one is for the lower case, to simplify if the current character is more than a and less than z.*/
            text[i]= 'a' + ((t-'a'+shift) % 26);} /*convert it to integer shift it once and loop is around from 25 to 0 where the alphabet is near the edge.*/
        else if (t >= 'A' && t <= 'Z') { /*Same thing for capital letters.*/
            text[i]= 'A' + ((t-'A'+shift) % 26);
        }
        printf("%c\n",text[i]);
    }
}
void decrypt(char text[], int shift) { /*Decryption function works the same way with minor differences.*/
    shift %= 26;

    for (int i = 0; i < strlen(text); i++) {
        char t =text[i];
        if (t >= 'a' && t <= 'z'){
            text[i]= 'a' + ((t-'a'-shift+26) % 26);} /*The minor difference being if the alphabet assigned to 0 shifts backwards and then it becomes negetive.*/
        else if (t >= 'A' && t <= 'Z') {
            text[i]= 'A' + ((t-'A'-shift+26) % 26); /*The code doesnt handle negetive numbers well so we add 26 so it stays positive.*/
        }
        printf("%c\n",text[i]);
    }
}


void Cipher_main() { /*Ze mein funktion.*/

    char text[256]; /*256 to prevent buffer overflow where it is never going to happen anyway.*/
    int key;
    int method;
    setbuf(stdout, NULL); /*This is for the specific IDE im using code works fine even without it.*/

while (1) { /*While loop, this program runs forever as it should so not an error.*/
    printf("Enter text: ");
    scanf("%s",text);
    printf("Enter key: ");
    scanf("%d",&key);
    printf("Enter Method\n 1.Encrypt\n 2.Decrypt\n : ");
    scanf("%d",&method); /*This is where you pick a method.*/
    if (method==1) { /*And this is where the computer picks the method based on your choice.*/
        encrypt(text,key); /*Calling the encrypt function.*/
    }
    else if (method==2) {
        decrypt(text,key);
    }
    else {
        printf("Wrong Input\n"); /*Hey buddy you cant pick a third option its either 1 or 2*/
    }
}
printf("\nPress ENTER to exit..."); /*It doesnt close on purpose but I put it here anyway for future.*/
	    getchar();
	    getchar();
}
