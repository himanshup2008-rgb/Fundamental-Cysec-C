/*
 * Hex Dump.h
 *
 *  Created on: May 8, 2026
 *      Author: himan
 */

#ifndef HEXDUMP_H_
#define HEXDUMP_H_

int HexDump_main(void);

#endif /* HEXDUMP_H_ */
