/*
 ============================================================================
 Name        : XOR.c
 Author      : Himanshu Prasd Pandey
 Copyright   : Simple XOR encryptor IDK what to say wasnt that simple so I have my unique flare here if you make this add your own unique flare.
 Description : XOR encryptor.
 ============================================================================
 */
#include "XOR.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



void encryptXOR(char v[], char key){for (int i=0; i<strlen(v);i++){ /*This is the void function for encryption pretty simple I use ^operator to XOR v and key*/
	char enk = v[i]^key;
	printf("%02X ",(unsigned char )enk); /*I print it here*/
	}
}
void decryptXOR(char v[], char key){ /*This is the decrypt function alot more complicated and was a gigantic headache*/
	char hex[256]; hex[0]='\0'; /*declaring variables that will hold the number we read \0 makes each string begin empty*/
	char dec[256]; dec[0]='\0';
	char txt[256]; txt[0]='\0';



//Bunch of old code//

//char *token= strtok(v, " "); //Think of it as scissors you cut every chunk before " " which is a space gap.//
//while(token!=NULL){ *//*Loop goes on until NULL is returned which esentially means until its done and no more value is left to return//


	int len=strlen(v);
	for(int i=0;i<len;){
		char token[3];
		int tok=0;

		while (i<len && tok<2){
			if (v[i] !=  ' ') {
				token[tok++]=v[i];

			}
			i++;
		}
				token [tok]='\0';

				if(tok==2){long value= strtol(token, NULL, 16); /*turns hex into a number 16 for 16 bytes*/
				char dyk = value^key;/*dyk XORs the turned back hex and the key input*/
				strcat(hex, token); /*appends token to hex*/
				strcat(hex, " "); /*So basically adds the clipped hex into hex string, basically a hex piece with a space in front of it. */
				char dbuf[32]; /*Basically has the same function as the hex strcat except sprintf*/
				sprintf(dbuf, "%ld", value); /*What this does is turns number into text and adds it tto dbuf*/
				strcat(dec, dbuf);
				strcat(dec, " ");
				int length= strlen(txt); /*Same thing*/
				txt[length]=dyk;
				txt[length+1]='\0';

	/*Old code */
	/*token= strtok(NULL, " ");*/


}}
	printf("%-6s | %-6s | %-6s\n", hex, dec, txt); /*The fruits of doing the three same things. I can now add the results of decryption to different column panels*/



}


int XOR_main() { /*The country's constitution*/

	char v[256];
	char key;
	int method;
	setbuf(stdout,NULL); /*Third time Im saying this but I need this line for my IDE since it breaks without it, the code works without it*/
	int c;
	while ((c = getchar()) != '\n' && c != EOF) {} /*This is to clear the input buffer leftover from the master code*/


	printf("Please Enter the Text:");
	fgets(v, sizeof(v),stdin); /*since scanf wasnt working as intented I used fgets basically does the same thing*/
	v[strcspn(v,"\n")]=0; /*removes the new line in the end*/
	printf("Please Enter the Key:"); /*Print and Scan*/
	scanf(" %c", &key);
	printf("Key is: %c\n", key);
	printf("Enter Method\n 1.Encrypt\n2.Decrypt\n: ");
	scanf("%d", &method);

	if(method==1){
		encryptXOR(v,key); /*calling encrypt function*/
	}
	else if (method==2){
		decryptXOR(v,key); /*calling decrypt function*/

	}
	printf("\nPress ENTER to exit...");/*Close command to stop it from closing. On its own anyway.*/
				    getchar();
				    getchar();
	return 0;

	}

