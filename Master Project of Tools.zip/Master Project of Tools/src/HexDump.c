/*
 ============================================================================
 Name        : Hex.c
 Author      : Himanshu Prasad Pandey
 Copyright   : Whatever anyone can do this, learning from it is the most important part.
 Description : Hex dump in C, with plain text.
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "HexDump.h"

int HexDump_main(void) {
	setbuf(stdout, NULL);
	FILE *test=fopen("HexTest.txt", "rb"); /*fopen to open FILE called test*/

	if (test==NULL){ /*Failure prints error*/
		printf("Error");
		printf("\nPress Enter to exit");
		getchar();
		return 1;
	}
	printf("Succesfull\n");

	char byte[16]; /*Well this is the character array, idk what to say about this tbh*/
	size_t buffer; /*This is what counts individual bytes*/
	while((buffer=fread(byte, 1,16,test))>0){ /*A while loop, in kid terms reads the number of boxes*/
		for(size_t i=0; i<buffer; i++ ){ /*A for loop, in even juvenile terms after the boxes are read it prints the number of items inside each of the boxes*/
			printf("%02X ", (unsigned char) byte[i]); /*This is called casting, char can be negative so unsigned car ensures 0-255 required for hex printing*/
		}
		printf(" | ");/*Well well what do we have here, guess what this does.*/
	for (size_t i=0;i<buffer; i++){
		unsigned char t=byte[i];

		if (isprint(t)){ /*isprint checks if the value is in ASCII, works well with if-else statements and unsigned char values else prepare for uncontrolled loops, crashes etc.*/

		printf("%c", t);
	}
		else printf(".");
	}
	printf(" |\n");
	}
	fclose(test); /* opposite of fopen*/
	printf("\nPress ENTER to exit..."); /*Exit command since it closed on its own*/
				    getchar();
				    getchar();

	return 0;
	}

