/*
 * Password Checker.h
 *
 *  Created on: May 8, 2026
 *      Author: Himanshu
 */

#ifndef CHECKER_H
#define CHECKER_H

int Checker_main();

#endif
