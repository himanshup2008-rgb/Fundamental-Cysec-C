/*
 ============================================================================
 Name        : Master.c
 Author      : Himanshu Prasad Pandey
 Version     :
 Copyright   : 
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "Cipher.h"
#include "Checker.h"
#include "HexDump.h"
#include "XOR.h"

int main() {
	    int choice;
	    setbuf(stdout, NULL);

	    printf("Select a project to run:\n");
	    printf("1. Caesar Cipher 1\n");
	    printf("2. Password Checker 2\n");
	    printf("3. Hex Dump 3\n");
	    printf("4. XOR Encryptor 4\n---->");
	    scanf(" %d", &choice);

	    switch(choice) {
	            case 1: Cipher_main(); break;
	            case 2: Checker_main(); break;
	            case 3: HexDump_main(); break;
	            case 4: XOR_main(); break;
	            default: printf("Invalid choice\n");
	    }

	    return 0;
	    printf("\nPress ENTER to exit...");
	    			    getchar();
	    			    getchar();
	}
