#ifndef XOR_H
#define XOR_H

int XOR_main();

#endif
